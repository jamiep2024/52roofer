export default function RoofingCompaniesMarlboroughWiltshire() {
  return (
    <div>
      <h1>Roofing Companies in Marlborough, Wiltshire</h1>
      <p>Content for roofing companies in Marlborough, Wiltshire.</p>
    </div>
  );
}
