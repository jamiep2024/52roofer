export default function RoofingCompaniesBradfordOnAvonWiltshire() {
  return (
    <div>
      <h1>Roofing Companies in Bradford-on-Avon, Wiltshire</h1>
      <p>Content for roofing companies in Bradford-on-Avon, Wiltshire.</p>
    </div>
  );
}
