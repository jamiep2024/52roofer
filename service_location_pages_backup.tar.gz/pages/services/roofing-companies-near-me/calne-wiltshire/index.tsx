export default function RoofingCompaniesCalneWiltshire() {
  return (
    <div>
      <h1>Roofing Companies in Calne, Wiltshire</h1>
      <p>Content for roofing companies in Calne, Wiltshire.</p>
    </div>
  );
}
