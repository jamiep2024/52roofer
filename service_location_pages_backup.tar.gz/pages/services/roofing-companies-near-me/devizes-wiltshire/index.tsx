export default function RoofingCompaniesDevizesWiltshire() {
  return (
    <div>
      <h1>Roofing Companies in Devizes, Wiltshire</h1>
      <p>Content for roofing companies in Devizes, Wiltshire.</p>
    </div>
  );
}
