export default function RoofingCompaniesWarminsterWiltshire() {
  return (
    <div>
      <h1>Roofing Companies in Warminster, Wiltshire</h1>
      <p>Content for roofing companies in Warminster, Wiltshire.</p>
    </div>
  );
}
