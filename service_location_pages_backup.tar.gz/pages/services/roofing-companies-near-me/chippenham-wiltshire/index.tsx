export default function RoofingCompaniesChippenhamWiltshire() {
  return (
    <div>
      <h1>Roofing Companies in Chippenham, Wiltshire</h1>
      <p>Content for roofing companies in Chippenham, Wiltshire.</p>
    </div>
  );
}
